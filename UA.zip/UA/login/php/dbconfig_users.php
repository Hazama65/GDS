<?php
    // define('DB_HOST', 'localhost');
    // define('DB_NAME', 'ui_apoyo');
    // define('DB_USERNAME', 'root');
    // define('DB_PASSWORD', '');


    define('DB_HOST', 'srv961.hstgr.io');
    define('DB_NAME', 'u772081794_ua');
    define('DB_USERNAME', 'u772081794_ua');
    define('DB_PASSWORD', '>5ZfF>sk');
?>