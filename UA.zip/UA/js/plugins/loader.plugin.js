
export function showLoadingOverlay() {
    document.getElementById('loading-overlay').style.display = 'flex';
}

export function hideLoadingOverlay() {
    document.getElementById('loading-overlay').style.display = 'none';
}

