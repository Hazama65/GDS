function redirectToPage(url) {
    window.location.href = url; // Redirigir a la URL especificada al hacer clic en el card
}
