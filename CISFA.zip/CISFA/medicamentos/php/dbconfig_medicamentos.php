<?php
    // local
    define('DB_HOST','localhost');
    define('DB_NAME','medicamentos');
    define('DB_USERNAME','root');
    define('DB_PASSWORD','');


    // hostinger

    // define('DB_HOST','srv961.hstgr.io');
    // define('DB_NAME','u772081794_medicamentos');
    // define('DB_USERNAME','u772081794_medicamentos');
    // define('DB_PASSWORD','l#>Oejqsb+8B');

?>